export const environment = {
  	production: true,
  	apiUrl: 'http://localhost/angular_blog/server/public/api/v1'
};
