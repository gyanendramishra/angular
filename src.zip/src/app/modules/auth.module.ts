import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { AuthRoutingModule } from '../routes';
import { LoginComponent, RegisterComponent, ForgotPasswordComponent, ResetPasswordComponent } from '../auth';

@NgModule({
	imports: [
	    CommonModule,
	    ReactiveFormsModule,
	    AuthRoutingModule
	],
	declarations: [
		LoginComponent, 
		RegisterComponent, 
		ForgotPasswordComponent, 
		ResetPasswordComponent
	]
})
export class AuthModule { }
