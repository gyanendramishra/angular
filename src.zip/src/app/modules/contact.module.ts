import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { ContactRoutingModule } from '../routes';
import { ContactComponent } from '../contact/contact.component';

@NgModule({
  	imports: [
	    CommonModule, 
	    FormsModule,
	    ContactRoutingModule
  	],
  	declarations: [
    	ContactComponent,
  	],
  	providers: []
})
export class ContactModule { }
