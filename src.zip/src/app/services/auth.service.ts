import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

import { User } from '../models';
import { environment } from '../../environments/environment';

@Injectable({
  	providedIn: 'root'
})
export class AuthService {
    
    apiUrl = environment.apiUrl;

	constructor(
		private http: HttpClient
	) { }
    
    /*
        Method to login user
        @param (string) email
        @param (string) password
        @param (boolean) remember_me
        @return response user
    */
    login(email: string, password: string, remember_me: boolean) {
        return this.http.post<any>(`${this.apiUrl}/auth/login`, { email: email, password: password, remember_me: remember_me })
            .pipe(map(user => {
                // login successful if there's a passport token in the response
                if (user && user.access_token) {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    localStorage.setItem('currentUser', JSON.stringify(user));
                }
 
                return user;
            }));
    }

    /*
        Method to register user
        @param (user) user
        @return response user
    */

    register(user: User) {
        return this.http.post(`${this.apiUrl}/auth/register`, user);
    }

    /*
        Method to logout user
    */
    logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
    }

    get isLoggedIn() {
        if (localStorage.getItem('currentUser')) {
            // logged in so return true
            return true;
        }
    }
}
