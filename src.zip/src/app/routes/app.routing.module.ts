import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent }      from '../home/home.component';
import { ContactComponent }      from '../contact/contact.component';
import { NotFoundComponent }      from '../not-found/not-found.component';

const routes: Routes = [
  	{ path: '', component: HomeComponent },
  	{ path: 'contact-us', component: ContactComponent },
  	{ path: '404', component: NotFoundComponent },
  	{ path: '**', component: NotFoundComponent }
];

@NgModule({
	exports: [ RouterModule ],
	imports: [ RouterModule.forRoot(routes) ],
})
export class AppRoutingModule { }
