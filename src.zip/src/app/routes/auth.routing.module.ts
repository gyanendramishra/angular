import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent, RegisterComponent, ForgotPasswordComponent, ResetPasswordComponent } from '../auth';

const routes: Routes = [
  	{ path: 'login', component: LoginComponent },
  	{ path: 'register', component: RegisterComponent },
  	{ path: 'forgot-password', component: ForgotPasswordComponent },
  	{ path: 'reset-password', component: ResetPasswordComponent }
];

@NgModule({
  	exports: [RouterModule],
  	imports: [RouterModule.forRoot(routes)]
})
export class AuthRoutingModule { }
