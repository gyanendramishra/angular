import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { AppComponent } from './app.component';
import { AlertComponent } from './alert/alert.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { HomeComponent } from './home/home.component';

import { ContactModule, AboutModule, AuthModule, DashboardModule } from './modules';

import { AppRoutingModule } from './routes';
import { AlertService, AuthService } from './services';
import { AuthGuard } from './guards';
import { PassportInterceptor, ErrorInterceptor, fakeBackendProvider } from './helpers';

@NgModule({
    imports: [
        BrowserModule,
        HttpClientModule,
        ContactModule,
        AboutModule,
        AuthModule,
        DashboardModule,
        AppRoutingModule,
    ],
    declarations: [
        AppComponent,
        AlertComponent,
        HeaderComponent,
        FooterComponent,
        NotFoundComponent,
        HomeComponent
    ],
    providers: [
        AuthGuard,
        AlertService,
        AuthService,
        { provide: HTTP_INTERCEPTORS, useClass: PassportInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
        fakeBackendProvider
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }
